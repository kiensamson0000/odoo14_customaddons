# -*- coding: utf-8 -*-

from . import haravan_collections
from . import haravan_companies
from . import haravan_vendors
from . import haravan_seller
from . import product_category_inherit
from . import product_template_inherit
from . import product_product_inherit
from . import res_company_inherit
from . import sale_order_inherit